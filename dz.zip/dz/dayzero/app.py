import json
from flask import Flask, redirect, render_template, url_for, request, flash, jsonify,Response, send_from_directory
from flask_httpauth import HTTPBasicAuth
from models import db,bootstrap,NodeModel
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from nornir_utils.plugins.functions import print_result
from nornir import InitNornir
from nornir.core.filter import F
from nornir_scrapli.tasks import send_configs, send_configs_from_file
from parser import Parser
from helpers import render_config_data, write_config_data, CONFIG_OPTIONS
import pathlib
import pandas as pd
import yaml
import sys
import os
import random
import ciscoparser
import datetime
from time import sleep
import io
import re
import csv
import time
from flask_restful import inputs
import codecs
import logging
import email.utils
try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse
from collections import OrderedDict
import datetime
from waitress import serve

##### CONSTANTS ################################################################
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
BASE_URL = 'http://172.16.30.50:9000/file/'  # Default base URL
UPLOAD_DIR = 'uploaded'  # Default upload folder
HIDE = r'\..*|autoinstall|media'  # Folders to hide


##### FUNCTIONS ################################################################
auth= HTTPBasicAuth()
app = Flask(__name__)
app.config["SECRET_KEY"] = "aSecretKey"
app.config["UPLOAD_FOLDER"] = BASE_DIR

user='test'
pw='test123'

users={user: generate_password_hash(pw)}


def send_configs_from_file2(task, filename):
	config_dir = f"C9k-configs/{task.host.name}/{filename}"
	task.run(task=send_configs_from_file, file=config_dir, eager=True)
	

def get_inventory(target_hosts=[]):
    nr = InitNornir("config.yaml")
    if target_hosts:
        return nr.filter(F(name__any=target_hosts))
    else:
        return nr.filter()

def generate_inventory(filename):
	df = pd.read_excel(filename)

	if df[["name", "hostname", "groups"]].isnull().values.any():
		return "mandatory columns (name, hostname and groups) can not be empty"
	else:
		hosts = {}

		rows = df.values.tolist()
		for row in rows:
			name, hostname,port, username, password, groups = row
			hosts[name] = {
				"hostname":hostname,
				"port": port if not pd.isna(port) else 22,
				"username": username if not pd.isna(username) else None,
				"password": password if not pd.isna(password) else None,
				"groups": groups.split(",")
				}

		f = open('hosts.yaml', 'w+')
		yaml.dump(hosts, f, allow_unicode=True)

def generate_configuration(filename):
	base_dir = f"C9k-configs/"
	pathlib.Path(base_dir).mkdir(parents=True, exist_ok=True)

	cfg = {}
	cfg["l3interfaces"] = filename['l3interface']
	cfg["l2interfaces"] = filename['interface']
	hostname=filename['hostname']
	config_dir = f"{base_dir}/{hostname}"
	pathlib.Path(config_dir).mkdir(parents=True, exist_ok=True)
	template_name1 = f"{'l2interface'}.j2"
	data1 = render_config_data(filename, template_name1)
	write_config_data(data1, config_dir, f"{'l2interface'}-config")
	template_name2 = f"{'l3interface'}.j2"
	data2 = render_config_data(filename, template_name2)
	write_config_data(data2, config_dir, f"{'l3interface'}-config")


def generate_configuration2(filename):
        base_dir = f"uploaded/configs/"
        pathlib.Path(base_dir).mkdir(parents=True, exist_ok=True)
        hostname=filename['hostname']
        df=pd.read_excel("Izmir_ITMM_template.xlsx", sheet_name='Core Switching')
        m2=df['stack Role']=='master' 
        m1=df['Switch Name']==hostname
        serial_nr=df.loc[m1&m2, 'Serial Number'].values[0]
        template_name1 = f"{'l2interface'}.j2"
        template_name2 = f"{'mapping'}.j2"
        data2= render_config_data(filename, template_name2)
        data1 = render_config_data(filename, template_name1)
        #write_config_data(data1, config_dir, f"{'l2interface'}-config")		
        write_config_data(data1, base_dir, f"{serial_nr}.txt")
        write_config_data(data2, base_dir, f"{serial_nr}-mapping")



@auth.verify_password
def verify_password(username, password):
    if username in users:
        return check_password_hash(users.get(username), password)
    return False


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/inventory")
def inventory():
    nodes = NodeModel.query.all()
    return render_template("inventory.html", nodes=nodes)

"""
@app.route("/inventory", methods=['GET','POST'])
def inventory():

	if request.method == 'POST':
		file = request.files["file"]
		filename = secure_filename(file.filename)
		if filename != "inventory.xlsx":
			flash('filename should be inventory.xlsx')
		else:
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			flash('{filename} uploaded successfully')
			generate_inventory(filename)

	hosts = get_inventory().inventory.dict()["hosts"].values()

	return render_template("inventory.html", hosts=hosts)
"""
@app.route("/inventory/list", methods=["GET"])
def get_nodes():
    nodes = NodeModel.query.all()
    print(nodes)
    return jsonify([node.to_json() for node in nodes])

@app.route("/inventory/<int:id>", methods=["GET"])
def get_book(id):
    node = NodeModel.query.get(id)
    print(node)
    if node is None:
        abort(404)
    return render_template("node.html", id=id)

@app.route("/inventory/delete/<int:id>", methods=["POST"])
def delete(id):
	node = NodeModel.query.get(id)
	if node is None:
		abort(404)
	f = open('hosts.yaml', 'r')
	f2=yaml.safe_load(f)
	del f2[node.name]
	print(f2)
	f3 = open('hosts.yaml', 'w')
	yaml.safe_dump(f2, f3, allow_unicode=True)
	db.session.delete(node)
	db.session.commit()

	return redirect(url_for("inventory"))

@app.route('/inventory/add_node/', methods=['POST'])
def add_node():
	if not request.form:
		abort(400)
	node = NodeModel(
		name=request.form.get('Host'),
		hostname=request.form.get('Address'),
		port=int(request.form.get('Port') or "22"),
		username=request.form.get('Username') or "installer",
		password=request.form.get('Password') or "installer"
	)
	db.session.add(node)
	db.session.commit()

	host={}
	host[node.name]={
			"hostname":node.hostname,
			"port":node.port,
			"username": node.username,
			"password": node.password,
			"groups": ["ios"]
			}

	f = open('hosts.yaml', 'r')
	f2=yaml.safe_load(f)
	if f2 is None:
		f2={}
	f2.update(host)
	f3 = open('hosts.yaml', 'w')
	yaml.safe_dump(f2, f3, allow_unicode=True)

	return redirect(url_for("inventory"))

@app.route('/inventory/update_node/<int:id>', methods=['POST'])
def update_node(id):
	if not request.form:
			abort(400)
	node = NodeModel.query.get(id)
	if node is None:
		abort(404)
	node.name = request.form.get('Host', node.name)
	node.hostname = request.form.get('Address', node.hostname)
	node.port = request.form.get('Port', node.port)
	node.username = request.form.get('Username', node.username)
	node.password = request.form.get('Password', node.password)   
	db.session.commit()

	host={}
	host[node.name]={
			"hostname":node.hostname,
			"port":node.port,
			"username": node.username,
			"password": node.password,
			"groups": ["ios"]
			}

	f = open('hosts.yaml', 'r')
	f2=yaml.safe_load(f)
	f2.update(host)
	f3 = open('hosts.yaml', 'w')
	yaml.safe_dump(f2, f3, allow_unicode=True)



	return redirect(url_for("inventory"))


@app.route("/configs/get/<filepath>")
def get_configs_file(filepath):
	host,config_file = filepath.split(":")
	configpath = f"{BASE_DIR}/uploaded/configs/{config_file}"
	message={}
	with open(configpath) as f:
		message["config"] =  f.read()
		message["title"] = f"{host} - {config_file}"
	return jsonify(message)


@app.route("/config/get/<filepath>")
def get_config_file(filepath):
	host,config_file = filepath.split(":")
	configpath = f"{BASE_DIR}/C9k-configs/{host}/{config_file}"
	message={}
	with open(configpath) as f:
		message["config"] =  f.read()
		message["title"] = f"{host} - {config_file}"
	return jsonify(message)

@app.route("/script/get/<filepath>")
def get__file(filepath):
	configpath = f"{BASE_DIR}/scripts/{filepath}"
	message={}
	with open(configpath) as f:
		message["script"] =  f.read()
	return jsonify(message)
@app.route("/generate", methods=['GET','POST'])
def generate():
	if request.method == 'POST':
		file = request.files["file"]
		filename = secure_filename(file.filename)
		file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
		flash('config uploaded successfully')

		dissector = ciscoparser.Dissector.from_file('ios.yaml')
		parsed_file=(dissector.parse_file(filename))
		parsed_file['interface']=[(lambda d: d.update(name=key) or d) (val) for (key, val) in parsed_file['interface'].items()]
		for el in parsed_file['interface']:
			if not 'mode' in el:
				el['mode']="l3"
		parsed_file['l3interface']=[]
		for el in parsed_file['interface']:
			if el['mode']=='l3':
				parsed_file['l3interface'].append(el)
				parsed_file['interface'].remove(el)
 	
		generate_configuration(parsed_file)

	mapping = {}
	try:
		dir_list = sorted(os.listdir("C9k-configs"))
	except FileNotFoundError:
		pass
	else:
		for subdir in dir_list:
			if not subdir=='.DS_Store':
				files = os.listdir(f"C9k-configs/{subdir}")
				mapping[subdir] = files

	return render_template("generate.html", config_files=mapping)

@app.route("/generate_ztp", methods=['GET','POST'])
def generate_ztp():
	if request.method == 'POST':
		file = request.files.getlist('file')
		print(file)
		for files in file:
			filename = secure_filename(files.filename)
			print(filename)
			files.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

			dissector = ciscoparser.Dissector.from_file('ios.yaml')
			parsed_file=(dissector.parse_file(filename))
			parsed_file['interface']=[(lambda d: d.update(name=key) or d) (val) for (key, val) in parsed_file['interface'].items()]
			for el in parsed_file['vlan']:
				if not 'name' in parsed_file['vlan'][el]:
					parsed_file['vlan'][el]['name']=str('VLAN_'+el)
			vlans=[]
			vlan_keys=['id', 'name']
			for el in parsed_file['vlan']:
				vlans.append([el,parsed_file['vlan'][el]['name']])
			parsed_file['vlans']=[dict(zip(vlan_keys, el)) for el in vlans]
			for el in parsed_file['interface']:
				if not 'mode' in el:
					el['mode']="l3"
			parsed_file['l3interface']=[]
			parsed_file['l2_access']=[]
			parsed_file['l2_trunk']=[]
			parsed_file['port_channel']=[]
			for el in parsed_file['interface']:
				if el['mode']=='access':
					parsed_file['l2_access'].append(el)
				if el['mode']=='trunk':
					el['allowed_vlan']=[','.join(el['allowed_vlan'])]
					if 'ort' in el['name']:
						parsed_file['port_channel'].append(el)
					else:	
						parsed_file['l2_trunk'].append(el)
				if el['mode']=='l3':
					if el['ipv4']:
						print(el['name'] +' ' +el['mode'])
						parsed_file['l3interface'].append(el)

			generate_configuration2(parsed_file)

	mapping = {}
	try:
		#dir_list = sorted(os.listdir("C9k-configs"))
		dir_list = sorted(os.listdir("uploaded/configs"))
	except FileNotFoundError:
		pass
	else:
		#for subdir in dir_list:
		#	if not subdir=='.DS_Store':
		#		files = os.listdir(f"C9k-configs/{subdir}")
		files = os.listdir(f"uploaded/configs/")

		df=pd.read_excel("Izmir_ITMM_template.xlsx", sheet_name='Core Switching')
		for el in files:
			if ".txt" in el:
				try:
					m1=df['Serial Number']==el[:-4]
					sw_name=df.loc[m1, 'Switch Name'].values[0]
					mapping[sw_name] =[]
					mapping[sw_name].append(el)
					print(mapping)
				except:
					print(el)
		for el in files:
			if "mapping" in el:
				m1=df['Serial Number']==el[:-8]
				sw_name=df.loc[m1, 'Switch Name'].values[0]
				mapping[sw_name].append(el)
				print(mapping)

	return render_template("generate_ztp.html", config_files=mapping)


@app.route("/configure", methods=['GET','POST'])
def configure():
	hosts = get_inventory().inventory.dict()["hosts"].values()
	results = []
	config_db=[]
	df= pd.read_csv('config_db.csv')
	df=df.sort_values(by='Time',ascending=False)
	for index, rows in df.iterrows():
		new_list=[rows.Node, rows.Config, rows.Status, rows.Result, rows.Time]
		config_db.append(new_list)
	if request.method == 'POST':
		devices = request.form.getlist("device")
		configs = request.form.getlist("config")
		target_hosts = get_inventory(target_hosts=devices)

		for config in CONFIG_OPTIONS:
			if config in configs:
				config_results = target_hosts.run(send_configs_from_file2, filename=f"{config}-config")
				for host in config_results:
					now = datetime.datetime.now().replace(microsecond=0)
					result = config_results[host][1]
					print(result.result)
					status = "failed" if result.failed else "success"
					results.append((host, config, status, result,str(now)))
	if not results ==[]:
			for nodes in results:
				df=pd.DataFrame(nodes).T
				df.to_csv('config_db.csv', mode='a', index=False, header=False)

	return render_template("configure.html", hosts=hosts, config_options=CONFIG_OPTIONS, results=results, config_db=config_db)
"""
@app.route('/syslog')
def syslog():
    def generate():
        with open('/private/var/log/system.log') as f:
            while True:
                yield f.read()
                sleep(1)

    return app.response_class(generate(), mimetype='text/plain'), render_template("syslog.html")
"""

@app.route('/script/<id>')
def ztp(id):
	configpath = f"{BASE_DIR}/ztp/{id}"
	files = os.listdir(f"scripts")
	print(files)
	for el in files:
		if ".py" in el:
			print(el)
			with open(configpath) as f:
				output=f.read()
				return app.response_class(output, mimetype='text/plain')

@app.route('/test', methods=['GET','POST'])
@auth.login_required
def script():
	files = os.listdir(f"scripts")
	mapping=[]
	for el in files:
		if not el=='.DS_Store':
			mapping.append(el)
			print(el)

	return render_template("test.html", config_files=mapping)

'''
@app.before_request
def ztp_log():
    """ Logs request from client to stderr """
    ra, qs = request.remote_addr, request.query_string
    path = request.path + '?' + qs if qs else request.path
    logging.info('%s - %s %s', ra, request.method, path)
'''
@app.route("/ztp/")
def ztp_index():
    return render_template("ztp.html")

@app.route('/ztp/file/<path:filename>' ,methods=['GET'])
def ztp_get_config_file(filename):
    configpath = f"{BASE_DIR}"
    return send_from_directory(configpath, filename, as_attachment=True)

@app.route('/ztp/file/<path:filename>' , methods=['DELETE'])
def ztp_delete_file(filename):
    configpath = f"{BASE_DIR}"
    try:
        os.remove(os.path.join(configpath, filename))
        return jsonify('deleted')
    except OSError as e:
        return(e)

@app.route('/ztp/file/<filepath>',methods=['PUT'] )
def ztp_put_file(filepath):
    """ Handles file upload """
    folder, filename = os.path.split(filepath)
    folder = folder or UPLOAD_DIR
    upload = request.files(filename=filename)
    try:
        if folder and not os.path.exists(folder):
            os.makedirs(folder)

        upload.save(os.path.join(folder, upload.filename))
    except (OSError, IOError) as e:
        return(e)

@app.route('/ztp/file', methods=['POST'])
def ztp_post_file():
    """ Handles form data for file uploading """
    folder = request.form['folder'] or UPLOAD_DIR
    upload = request.files['upload']
    try:
        if folder and not os.path.exists(folder):
            os.makedirs(folder)

        upload.save(os.path.join(folder, upload.filename))
        return jsonify('success')
    except (OSError, IOError) as e:
        return(e)

@app.route('/ztp/list')
def ztp_get_list():
    """ Compiles a list of files and sends it to the web server """
    result = []
    seen = set()
    for root, dirs, files in os.walk('.', followlinks=True):
        seen.add(os.path.realpath(root))
        # Don't visit hidden and same directories
        dirs[:] = [name for name in dirs if not re.match(HIDE, name)
                   and os.path.realpath(os.path.join(root, name)) not in seen]
        if root == './uploaded':
            for name in files:
                filename = os.path.join(root, name)
                stats = os.stat(filename)
                mtime = time.strftime('%x %X', time.localtime(stats.st_mtime))
                result.append({'file': filename.replace('\\', '/'),
                               'time': mtime, 'size': stats.st_size})
    resp=Response(json.dumps(result),mimetype='application/json' )
    resp.headers['Pragma']='no-cache'
    resp.headers['Cache-Control']="no-cache, no-store, must-revalidate"
    resp.headers['expires']=0

    return resp 
@app.route('/ztp/data', methods=['GET'])
def ztp_get_data():
    """ Parses JSON file into an OrderedDict and sends it to the web server """

    data = [OrderedDict(base_url=BASE_URL)]
    try:
        if os.path.exists('data.json'):
            # Include last modified date in response header
            value = email.utils.formatdate(os.path.getmtime('data.json'),
                                           usegmt=True)
            with open('data.json') as infile:
                data = json.load(infile, object_pairs_hook=OrderedDict)

        return Response(json.dumps(data), headers={'Pragma':'no-cache','Cache-Control' : 'no-cache, no-store, must-revalidate',
            'Pragma':'no-cache'}, mimetype='application/json')
    except (ValueError, IOError) as e:
        error(e)

@app.route('/ztp/data', methods=['POST'])
def ztp_post_data():
    """ Parses posted JSON data into an OrderedDict and writes to file """
    # Make sure the data has not changed in the meantime
    ius = request.if_modified_since
    if ius and int(os.path.getmtime('data.json')) > ius:
        error('Discarding changes because server data was modified', 412)

    if request.content_type == 'application/json':
        # Load, validate and write JSON data
        try:
            data = json.loads(request.data,
                                       object_pairs_hook=OrderedDict)
            with open('data.json', 'w') as outfile:
                json.dump(data, outfile, indent=4)
            return jsonify('success')
        except (ValueError, IOError) as e:
            return(e)


@app.route('/ztp/csv')
def ztp_get_csv():
    """ Converts JSON file to CSV and sends it to web server """
    with open('data.json') as infile:
        data = json.load(infile, object_pairs_hook=OrderedDict)
        # Flatten JSON data
        flat_data = []
        for dct in data:
            flat = OrderedDict()
            for k in dct:
                if isinstance(dct[k], OrderedDict):
                    for kk in dct[k]:
                        flat[str(k) + '/' + str(kk)] = dct[k][kk]
                else:
                    flat[k] = dct[k]
            flat_data.append(flat)

        # Find column names
        columns = [k for row in flat_data for k in row]
        columns = list(OrderedDict.fromkeys(columns).keys())
        # Write CSV to buffer
        csvbuf = io.BytesIO() if sys.version_info[0] < 3 else io.StringIO()
        writer = csv.DictWriter(csvbuf, fieldnames=columns, delimiter=';')
        writer.writeheader()
        writer.writerows(flat_data)
        # Prepare response header
        resp=Response(csvbuf.getvalue(),mimetype='text/csv')


        resp.headers['Pragma']='no-cache'
        resp.headers['Cache-Control']='no-cache, no-store, must-revalidate'
        resp.headers['Content-Disposition']='attachment; filename="export.csv"'
        resp.headers['expires']=0

        return resp

@app.route('/ztp/csv', methods=['POST'])
def ztp_post_csv():
    """ Converts uploaded CSV to JSON data and writes to file """
    upload = request.files['upload']
    reader = csv.reader(codecs.iterdecode(upload, 'utf-8'), delimiter=';')
    headers = next(reader)
    data = []
    for row in reader:
        dct = OrderedDict(zip(headers, row))
        # Construct original cubic data structure
        cubic = OrderedDict()
        for k in dct:
            # Split keys
            kk = k.split('/')
            if dct[k] and len(kk) == 2:
                if kk[0] in cubic:
                    cubic[kk[0]].update(OrderedDict([(kk[1], dct[k])]))
                else:
                    cubic[kk[0]] = OrderedDict([(kk[1], dct[k])])
            else:
                if dct[k] == "True":
                    cubic[k] = True
                elif dct[k]:
                    cubic[k] = dct[k]
        data.append(cubic)

    # Validate and write JSON data
    try:
        #validate(data)
        with open('data.json', 'w') as outfile:
            json.dump(data, outfile, indent=4)

        return jsonify("OK")
    except (ValueError, IOError) as e:
        return (e)
@app.route('/ztp_log')
def ztp_log():
    """ Parses JSON log file and sends it to the web server """
    logbuf = []
    try:
    	if os.path.exists('log.json'):
    		with open('log.json') as infile:
    			logbuf = json.load(infile)
    except (ValueError, IOError) as e:
        return(e)
    return render_template("ztp_log.html", log_db=logbuf)

'''    # Send log buffer
@app.route('/ztp/log')
def ztp_log_get():
    """ Parses JSON log file and sends it to the web server """
    logbuf = []
    try:
        if os.path.exists('log.json'):
            with open('log.json') as infile:
                logbuf = json.load(infile)
    except (ValueError, IOError) as e:
        return(e)

    resp=Response(json.dumps(logbuf), mimetype='application/json')
    resp.headers['Pragma']='no-cache'
    resp.headers['Cache-Control']="no-cache, no-store"
    resp.headers['expires']=0
    return resp
    # Send log buffer

@app.route('/ztp/log')
def ztp_log_get():
    """ Parses JSON log file and sends it to the web server """
    logbuf = []
    try:
        if os.path.exists('log.json'):
            with open('log.json') as infile:
                logbuf = json.load(infile)
    except (ValueError, IOError) as e:
        return(e)

    resp=Response(json.dumps(logbuf), mimetype='application/json')
    resp.headers['Pragma']='no-cache'
    resp.headers['Cache-Control']="no-cache, no-store"
    resp.headers['expires']=0
    return resp
    # Send log buffer
'''
@app.route('/ztp/log', methods=['POST'])
@app.route('/ztp/log', methods=['PUT'])
def ztp_log_put():
    """ Appends JSON log entries to file """
    logbuf = []
    try:
        if os.path.exists('log.json'):
            with open('log.json') as infile:
                logbuf = json.load(infile)
    except (ValueError, IOError) as e:
        return(e)

    try:
        msg = json.loads(request.data)
        if not isinstance(msg, dict):
            return('Expected JSON object')

        msg['ip'] = request.remote_addr
        msg['time'] = time.strftime('%x %X')
        logbuf.append(msg)
        # Write log buffer to file
        with open('log.json', 'w') as outfile:
            json.dump(logbuf, outfile, indent=4)
            return jsonify(success=True)
    except (ValueError, IOError) as e:
        return(e)
'''
@app.route('/ztp/log', methods=['DELETE'])
def ztp_log_delete():
    """ Empties JSON log file """
    # Just write empty list to file
    try:
        with open('log.json', 'w') as outfile:
            json.dump([], outfile)
            return jsonify(success=True)
    except (ValueError, IOError) as e:
        return(e)
'''
def ztp_validate(data):
    """ Raises ValueError if data is invalid """
    if not isinstance(data, list):
        raise ValueError('Expecting JSON array of objects')

    defaults = OrderedDict()
    stack_values = []
    for my in data:
        if not isinstance(my, OrderedDict):
            raise ValueError('Expecting JSON array of objects')

        if 'stack' in my:
            if not isinstance(my['stack'], OrderedDict):
                raise ValueError("'stack' must be JSON object")

            # Check for keys that are not a natural number
            if any(True for k in my['stack'] if not k.isdigit()):
                raise ValueError("'stack' object name must be a number")

            # Check for blank values
            if any(True for v in my['stack'].values() if not v or v.isspace()):
                raise ValueError("Empty 'stack' object value not allowed")

            # Check for duplicate values
            if (len(set(my['stack'].values())) != len(my['stack'].values())
                    or any(v in stack_values for v in my['stack'].values())):
                raise ValueError("'stack' object values must be unique")

            stack_values.extend(my['stack'].values())
            # Check if either is set
            if (bool('version' in my or 'version' in defaults)
                    != bool('install' in my or 'install' in defaults)):
                raise ValueError("'version' and 'install' are both required")

            # Check $-based substitutions
            config = my.get('config', defaults.get('config', ''))
            template = my.get('template', defaults.get('template', ''))
            try:
                with open(config) as infile:
                    template += infile.read()
            except:
                pass
            subst = my.get('subst', defaults.get('subst', OrderedDict()))
            names = set(re.findall(r'\${?(\w+)}?', template))
            for name in names - set(subst.keys()):
                raise ValueError("'%s' not found in all 'subst' objects" % name)

        else:
            if defaults:
                raise ValueError("Only one object without 'stack' is allowed")
            defaults = my

        if 'subst' in my:
            if not isinstance(my['subst'], OrderedDict):
                raise ValueError("'subst' must be JSON object")

            if any(True for k in my['subst'] if k.startswith('$')):
                raise ValueError("'subst' object name should not start with $")

        if 'base_url' in my:
            result = urlparse(my['base_url'])
            if not all((result.scheme, result.netloc)):
                raise ValueError("'base_url' is not valid")

            if not result.path.endswith('/'):
                raise ValueError("'base_url' should end with /")

        # Check local path existence only
        for key in ('install', 'config'):
            result = urlparse(my.get(key, ''))
            if not result.scheme and result.path:
                if 'base_url' not in my and 'base_url' not in defaults:
                    raise ValueError("'base_url' required for relative paths")

                if not os.path.exists(my[key]):
                    raise ValueError("'%s' not found" % my[key])

        # Check for empty dicts
        if not all(v for v in my.values() if isinstance(v, OrderedDict)):
            raise ValueError('Empty JSON object not allowed')

        # Check for blank keys
        if any(True for k in my if not k or k.isspace()):
            raise ValueError('Empty JSON object name not allowed')

    return data

if __name__ == '__main__':

    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///nodes.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    bootstrap.init_app(app)
    db.init_app(app)
    db.init_app(app)
    @app.before_first_request
    def create_table():
        db.create_all()
 
    serve(app, host="0.0.0.0", port=9000)

