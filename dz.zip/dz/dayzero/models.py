from flask_sqlalchemy import SQLAlchemy
from flask_bootstrap import Bootstrap

 
db = SQLAlchemy()
bootstrap = Bootstrap()
 
class NodeModel(db.Model):
    __tablename__ = "table"
 
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(),unique = True)
    hostname = db.Column(db.String(),unique=True)
    port = db.Column(db.Integer, default=22)
    username = db.Column(db.String(80), default='installer')
    password = db.Column(db.String(80), default='installer')
 
    def to_json(self):
        return{
        'id': self.id,
        'name': self.name,
        'hostname': self.hostname,
        'port': self.port,
        'username': self.username,
        'password': self.password
        } 
