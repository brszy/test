import cli

print("Configure vlan interface, gateway, aaa, and set basic settings\n\n")
cli.configurep(["int gi1", "ip address 10.10.10.100 255.255.255.0", "no shut", "end"])
cli.configurep(["username developer privilege 15 secret 0 C1sco12345"])
cli.configurep(["interface Loopback0", "ip address 192.168.12.1 255.255.255.0", "end"])
cli.configurep(["aaa new-model", "aaa authentication login default local", "end"])
cli.configurep(["aaa authorization exec default local", "aaa session-id common", "end"])
cli.configurep(["line vty 0 15", "transport input all", "exec-timeout 0 0", "end"])
cli.configurep(["hostname csr1000v", "end"])
print("\n\n *** Executing show ip interface brief  *** \n\n")
cli_command = "sh ip int brief"
cli.executep(cli_command)